# Full Stack Task Manager (MERN)

A starter project for **Full Stack Development – I** (BCA Honours, Silver Oak
University). It's a working task manager built with React, Node.js,
Express, and MongoDB — structured so each folder lines up with a week in
your Experiential Learning Workbook.

## Structure

```
fullstack-project/
├── client/          React frontend (Vite)
│   └── src/
│       ├── components/   TaskForm, TaskItem, TaskList
│       ├── pages/        Home, About
│       ├── hooks/        useFetch (custom hook)
│       └── api/          axios config
└── server/          Express backend
    ├── config/      MongoDB connection
    ├── models/      Task schema (Mongoose)
    ├── controllers/ Route logic
    ├── routes/      REST API endpoints
    └── middleware/  Error handling
```

## How it maps to the workbook

| Week | Topic | Where to look |
|---|---|---|
| 1 | React Setup & GitHub | `client/` — run it, then `git init` the whole folder |
| 2 | Components & Props | `client/src/components/` |
| 3 | useState | `TaskForm.jsx` |
| 4 | useEffect & Lifecycle | `useFetch.js`, used in `Home.jsx` |
| 5 | React Router | `App.jsx`, `pages/` |
| 6 | Advanced Hooks | `useFetch.js` (custom hook) |
| 7 | API Integration, Node.js | `api/axiosConfig.js`, `server.js` |
| 8 | Express.js & Routing | `server/routes/taskRoutes.js` |
| 9 | MongoDB & Mongoose | `server/models/Task.js`, `config/db.js` |
| 10 | REST API Development | `server/controllers/taskController.js` |
| 11 | Frontend-Backend Integration & Deployment | connect both, deploy (see below) |
| 12 | Final Project Submission | extend this app into your own final project |

## Setup

### Backend
```bash
cd server
npm install
cp .env.example .env    # then set MONGO_URI to your MongoDB connection string
npm run dev              # starts on http://localhost:5000
```

### Frontend
```bash
cd client
npm install
cp .env.example .env
npm run dev               # starts on http://localhost:5173
```

You'll need a MongoDB instance — either install MongoDB locally, or create a
free cluster on MongoDB Atlas and paste its connection string into
`server/.env`.

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | /api/tasks | Get all tasks |
| GET | /api/tasks/:id | Get one task |
| POST | /api/tasks | Create a task |
| PUT | /api/tasks/:id | Update a task |
| DELETE | /api/tasks/:id | Delete a task |

## Deployment (Week 11)
- Frontend: Vercel or Netlify (`npm run build` → deploy the `dist/` folder)
- Backend: Render, Railway, or a VPS — set `MONGO_URI` and `CLIENT_URL` as
  environment variables
- Database: MongoDB Atlas
