// Demonstrates: props and event handling (Week 2)
export default function TaskItem({ task, onToggle, onDelete }) {
  return (
    <li className={`task-item ${task.completed ? "completed" : ""}`}>
      <span onClick={() => onToggle(task)}>{task.title}</span>
      {task.description && <p>{task.description}</p>}
      <button onClick={() => onDelete(task._id)}>Delete</button>
    </li>
  );
}
