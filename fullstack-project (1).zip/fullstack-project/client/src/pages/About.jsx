// Demonstrates: a second route for React Router (Week 5)
export default function About() {
  return (
    <div className="page">
      <h1>About This Project</h1>
      <p>
        A MERN stack task manager built as part of the Full Stack
        Development - I course. It demonstrates React components, hooks,
        routing, and a REST API backed by Express and MongoDB.
      </p>
    </div>
  );
}
