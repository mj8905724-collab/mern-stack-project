import TaskForm from "../components/TaskForm";
import TaskList from "../components/TaskList";
import useFetch from "../hooks/useFetch";
import api from "../api/axiosConfig";

// Demonstrates: useEffect (via useFetch), API integration (Weeks 4, 7, 10)
export default function Home() {
  const { data: tasks, loading, error, refetch } = useFetch("/tasks");

  const addTask = async (task) => {
    await api.post("/tasks", task);
    refetch();
  };

  const toggleTask = async (task) => {
    await api.put(`/tasks/${task._id}`, { completed: !task.completed });
    refetch();
  };

  const deleteTask = async (id) => {
    await api.delete(`/tasks/${id}`);
    refetch();
  };

  return (
    <div className="page">
      <h1>Task Manager</h1>
      <TaskForm onAdd={addTask} />
      {loading && <p>Loading tasks...</p>}
      {error && <p className="error">Error: {error}</p>}
      {!loading && !error && (
        <TaskList tasks={tasks} onToggle={toggleTask} onDelete={deleteTask} />
      )}
    </div>
  );
}
