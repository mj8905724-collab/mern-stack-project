import { useState, useEffect } from "react";
import api from "../api/axiosConfig";

// Custom hook demonstrating a reusable data-fetching pattern (Week 6: Advanced Hooks)
export default function useFetch(endpoint) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reloadFlag, setReloadFlag] = useState(0);

  const refetch = () => setReloadFlag((f) => f + 1);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    api
      .get(endpoint)
      .then((res) => {
        if (isMounted) setData(res.data);
      })
      .catch((err) => {
        if (isMounted) setError(err.message);
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, [endpoint, reloadFlag]);

  return { data, loading, error, refetch };
}
